---
name: verify-prediction-result-secondary
description: T5と独立したsourceまたは経路で結果を照合し、T6証拠だけを記録する。
version: 2.4.1
---

# verify-prediction-result-secondary

Allowed Task IDs for this Skill: **T06**.
Required tabs: `05_CONFIG`, `06_PREDICTIONS`, `07_SOURCE_MASTER`, `09_RESULTS`, `11_AUDIT_LOG`, `12_RUN_LOG`, `04_SCHEDULES`.

## Fixed contract and required support files

- Target Spreadsheet ID: `1ZGb__FQT25BPkzovq2UTfO4clvE7G71PiRm3yywSj6Y`
- Target base URL: `https://docs.google.com/spreadsheets/d/1ZGb__FQT25BPkzovq2UTfO4clvE7G71PiRm3yywSj6Y/edit`
- Contract ID: `PROJECT_SIXTH_PREDICTION_OPS`
- Schema version: `2.0.0`
- Runtime version: `2.4.1`
- Timezone: `Asia/Tokyo`
- GID dependency: `NONE`

Before any operational Sheet write, read **all five** packaged support files in `contracts/`: `00_RUNTIME_CONTRACT.md`, `10_SHEET_IO.md`, `20_LOG_LANES.md`, `30_STATE_MACHINE.md`, `40_ERROR_POLICY.md`. Their requirements are mandatory and supplement this SKILL.md.

Open only the fixed Spreadsheet above. Verify `contract_id`, `schema_version`, `spark_sheet_id`, `spark_sheet_url`, `gid_dependency`, `skill_package_version=2.4.1`, `task_package_version=2.4.1`, and `runtime_hardening_version=2.4.1`, and `log_cursor_contract_version=2.1.0`. Never use a gid URL, similarly named workbook, replacement workbook, or Drive fallback.

## Runtime / Task binding

This Skill runtime is exactly `2.4.1`. The invoking prompt must provide one allowed Task ID and the literal token `Required Skill Runtime=<TaskID>@2.4.1`. Exact-search `05_CONFIG` for `<taskid lower>_required_skill_version` and require `2.4.1`. The active runtime, Task token, and Sheet value must all match. Otherwise return `E024` and FAIL CLOSED before business writes.

Generate one random 16-hex run nonce and one run_id `RUN-<TaskID>-YYYYMMDD-HHMMSS-<nonce>` per invocation. Never reuse short suffixes.

## Deterministic I/O and logging

- Existing entity rows are always re-resolved by authoritative logical ID/key immediately before each write; one entity = one exact-row write. Never use list position, cached rows, relative offsets, or multi-entity rectangular writes.
- After every business write, exact-search and read back identity plus written fields.
- Never directly write `06_PREDICTIONS!AQ:AR`.
- Logs use only the current Task's dedicated lane and Sheet-owned cursor from `05_CONFIG`; never global tail/first blank/implicit append.
- Each audit_id is `AUD-<TaskID>-YYYYMMDD-HHMMSS-<nonce>-<4 digit sequence>`. Pre/post uniqueness checks are limited to the Task's own lane. After write, the exact target row is directly re-read and must match the full payload.
- Cursor `+1` immediately after a log write is advisory only; do not call a successful exact-row write failed merely because formula recalculation/read caching has not advanced the cursor yet.
- Heartbeat uses only the literal fixed A1 target and literal guard in the Task text/`05_CONFIG`. Never search `04_SCHEDULES` to derive a row and never add/subtract a row offset.
- Scheduled pure NOOP => fixed heartbeat only. Manual NOOP or any changed/HOLD/ERROR run => exactly one terminal RUN_LOG row in the Task's run lane plus fixed heartbeat.
- Immediately before terminal completion, re-count the eligible workset and report the real remaining count in the note. A contradiction is `E025`.
- URL fields accept only http(s) URLs or blank. `SUCCESS`/`NOOP` run rows keep error fields blank.




## Procedure

1. 対象条件はT5と同じ。1実行最大10件。
2. T5のoption/factを根拠にしない。`secondary_source_id` を優先し、可能なら別組織の公式・準一次情報で照合する。
3. 同一組織しか使えない場合は別ページ・別データを使い、その事情をfactに明記する。
4. `09_RESULTS` は `prediction_id+version` を一意キーとして検索する。0行ならprediction_id/versionを入れた新規1行を追加、1行ならその行だけを使用、2行以上ならE018としてHOLD/ERRORにして任意の1行を選ばない。resolution_ruleに照らしたchoice、URL、fact、確認時刻、source_id、run_idをT6列へ保存し、確定時は `t6_status=FINAL` とする。
5. T5と異なる結果でも修正・多数決せず、そのまま独立証拠として残す。未確定は `PENDING`。
6. 各結果確認を1 entityずつaudit記録する。run/NOOP記録は上記Deterministic I/O and loggingに従う。

## Do not

- T5をコピーしない。
- 不一致を多数決で消さない。
- SNS投稿を公式結果扱いしない。
- `06_PREDICTIONS.final_result` やT7列を変更しない。

## Missing / conflicting information

Use the stage-appropriate `HOLD`, `PENDING`, `ERROR`, `CONFLICT`, or `NOOP` state. Never invent missing facts.

## Write scope

`09_RESULTS` の `t6_*`、`11_AUDIT_LOG`、`12_RUN_LOG` のみ。
